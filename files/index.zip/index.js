const handler = async (event) => {
    let response = 'Célula de ahorros';
    
    return response;
};

exports.handler = handler;